package ru.localfast.core;

import cn.nukkit.Player;
import cn.nukkit.command.Command;
import cn.nukkit.command.CommandSender;
import cn.nukkit.plugin.PluginBase;
import cn.nukkit.utils.Config;

import java.io.File;
import java.util.Locale;

public final class LocalFastCore extends PluginBase {
    private static final int MAX_LEVEL = 100;
    private static final int POINTS_PER_LEVEL = 3;
    private static final int MAX_XP_GRANT = 1_000_000;
    private static final String[] STATS = {"strength", "health", "agility", "intelligence"};

    private Config players;

    @Override
    public void onEnable() {
        if (!getDataFolder().exists() && !getDataFolder().mkdirs()) {
            getLogger().error("Не удалось создать папку данных LocalFastCore.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        players = new Config(new File(getDataFolder(), "players.yml"), Config.YAML);
        getLogger().info("LocalFastCore 0.2.0 включён. Система уровней и характеристик готова.");
    }

    private String playerKey(Player player) {
        return player.getName().toLowerCase(Locale.ROOT).replace('.', '_');
    }

    private int get(Player player, String field, int fallback) {
        return players.getInt(playerKey(player) + "." + field, fallback);
    }

    private void set(Player player, String field, int value) {
        players.set(playerKey(player) + "." + field, value);
    }

    private void initialize(Player player) {
        String key = playerKey(player);
        String[] fields = {"level", "xp", "points", "strength", "health", "agility", "intelligence"};
        int[] defaults = {1, 0, 0, 0, 0, 0, 0};
        boolean changed = false;
        for (int i = 0; i < fields.length; i++) {
            String path = key + "." + fields[i];
            if (!players.exists(path)) {
                players.set(path, defaults[i]);
                changed = true;
            }
        }
        if (changed) players.save();
    }

    private int xpForNextLevel(int level) {
        return 100 + (level - 1) * 50;
    }

    private void giveXp(Player player, int amount) {
        initialize(player);
        int level = Math.max(1, Math.min(MAX_LEVEL, get(player, "level", 1)));
        long totalXp = (long) get(player, "xp", 0) + amount;
        int points = Math.max(0, get(player, "points", 0));

        while (level < MAX_LEVEL && totalXp >= xpForNextLevel(level)) {
            totalXp -= xpForNextLevel(level);
            level++;
            points += POINTS_PER_LEVEL;
            player.sendMessage("§a[LocalFast] Новый уровень: §e" + level + " §a( +" + POINTS_PER_LEVEL + " очка характеристик )");
        }

        if (level == MAX_LEVEL) totalXp = Math.min(totalXp, xpForNextLevel(MAX_LEVEL) - 1L);
        set(player, "level", level);
        set(player, "xp", (int) totalXp);
        set(player, "points", points);
        players.save();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("level") || name.equals("stats") || name.equals("addstat")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Эта команда доступна только игроку.");
                return true;
            }
            Player player = (Player) sender;
            initialize(player);

            if (name.equals("level")) {
                int level = get(player, "level", 1);
                sender.sendMessage("§6[LocalFast] §fУровень: §e" + level + "/" + MAX_LEVEL);
                sender.sendMessage("§fОпыт: §a" + get(player, "xp", 0) + "§7/§a" + xpForNextLevel(level)
                        + " §f| Очки: §b" + get(player, "points", 0));
                return true;
            }

            if (name.equals("stats")) {
                sender.sendMessage("§6[LocalFast] §eХарактеристики");
                sender.sendMessage("§fСила: §c" + get(player, "strength", 0)
                        + " §fЗдоровье: §c" + get(player, "health", 0));
                sender.sendMessage("§fЛовкость: §a" + get(player, "agility", 0)
                        + " §fИнтеллект: §b" + get(player, "intelligence", 0));
                sender.sendMessage("§fСвободные очки: §e" + get(player, "points", 0));
                return true;
            }

            if (args.length != 1) {
                sender.sendMessage("§e/addstat <strength|health|agility|intelligence>");
                return true;
            }
            String stat = args[0].toLowerCase(Locale.ROOT);
            boolean valid = false;
            for (String allowed : STATS) if (allowed.equals(stat)) valid = true;
            if (!valid) {
                sender.sendMessage("§cВыбери: strength, health, agility или intelligence.");
                return true;
            }
            int points = get(player, "points", 0);
            if (points < 1) {
                sender.sendMessage("§cУ тебя нет свободных очков характеристик.");
                return true;
            }
            set(player, stat, get(player, stat, 0) + 1);
            set(player, "points", points - 1);
            players.save();
            sender.sendMessage("§a[LocalFast] Характеристика " + stat + " увеличена на 1.");
            return true;
        }

        if (name.equals("lfadmin")) {
            if (!sender.hasPermission("localfast.admin")) {
                sender.sendMessage("§cНедостаточно прав.");
                return true;
            }
            if (args.length != 3 || !args[0].equalsIgnoreCase("xp")) {
                sender.sendMessage("§e/lfadmin xp <player> <amount>");
                return true;
            }
            Player target = getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage("§cИгрок не найден или не в сети.");
                return true;
            }
            try {
                int amount = Integer.parseInt(args[2]);
                if (amount < 1 || amount > MAX_XP_GRANT) throw new NumberFormatException();
                giveXp(target, amount);
                target.sendMessage("§a[LocalFast] Начислено опыта: " + amount);
                sender.sendMessage("§aИгроку " + target.getName() + " начислено " + amount + " опыта.");
            } catch (NumberFormatException exception) {
                sender.sendMessage("§cУкажи целое число от 1 до " + MAX_XP_GRANT + ".");
            }
            return true;
        }
        return false;
    }

    @Override
    public void onDisable() {
        if (players != null) players.save();
    }
}
